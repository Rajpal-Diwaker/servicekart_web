/*
 * @Author: Tripti Bhardwaj
 * @Date: April 5, 2021
 */


let async = require('async'),
    jwt = require('jsonwebtoken');
let dbConfig = require("../Utilities/dbConfig");

let util = require('../Utilities/util'),
    config = require('../Utilities/Config'),
    vendorDAO = require('../DAO/vendorDAO');

// let FCM = require('fcm-node');
// // let driverserverKey = 'AAAA_1psqb0:APA91bH1bHT_GHx_M4Qn97-vRDAxgdVf4NqknmwciHXRRU64W2BGwlU0UjpX5RcPDuZIJxZIEDcBIl5-xyXM2SUIzP35gRB_29GIMBLn9Jl1JPQkCaDDDNFD7HZow74VuPh7qXBkBzrU'; //put your server key here
// let driverserverKey = 'AAAABOhrkPQ:APA91bEXkat1xH4M04jKGPHOBZePJQ83n4nD3mSHQXQY8uRbckT5oLzCj4LafFgg7R1LSzvH_s97eoMHw0OyJtV-6xvhn9OLxdLhWOpJm38OAWzR3YSLjsclQ0dKO1Hny4J_lS8P-25t'; //put your server key here
// let driverfcm = new FCM(driverserverKey);


/****** Mobile Validation API *****/
let checkMobile = (data, cb) => {
    if (!data.mobile_no || !data.user_type) {
        cb({ "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
        return;
    }
    let UserData = {
        mobile_no: data.mobile_no,
        user_type: data.user_type
    }
    vendorDAO.getUsers(UserData, (err, dbData) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": util.statusMessage.MOBILE_EXIST, "result": null });
            return;
        } else {
            cb({ "statusCode": util.statusCode.OK, "statusMessage": util.statusMessage.NEW_MOBILE, "result": null });
            return;
        }
    });
}

/****** Email Validation API *****/
let checkEmail = (data, cb) => {
    if (!data.email_id || !data.user_type) {
        cb({ "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
        return;
    }
    let UserData = {
        email_id: data.email_id,
        user_type: data.user_type
    }
    vendorDAO.getUsers(UserData, (err, dbData) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": util.statusMessage.EMAIL_EXIST, "result": null });
            return;
        } else {
            cb({ "statusCode": util.statusCode.OK, "statusMessage": util.statusMessage.NEW_EMAIL, "result": null });
            return;
        }
    });
}

/******* signup API *******/
let signup = (data, files, cb) => {
    async.auto({
            checkUserExistsinDB: (cb) => {
                if (!data.country_code || !data.mobile_no || !data.store_name || !data.user_type || !data.email_id || !data.password || !data.open_days) {
                    cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                    return;
                }
                let criteria1 = {
                    mobile_no: data.mobile_no,
                    user_type: data.user_type
                }

                if (data.coming_from == 'panel') {
                    if (files.profile[0].transforms[1].location != undefined) {
                        data.store_logo = files.profile[0].transforms[1].location
                    }
                    if (files.pan[0].transforms[1].location != undefined) {
                        data.pan_card = files.pan[0].transforms[1].location
                    }
                    if (files.gst[0].transforms[1].location != undefined) {
                        data.gst = files.gst[0].transforms[1].location
                    }

                }
                vendorDAO.getUsers(criteria1, (err, dbData1) => {
                    if (err) {
                        cb(null, {
                            "statusCode": util.statusCode.INTERNAL_SERVER_ERROR,
                            "statusMessage": util.statusMessage.DB_ERROR,
                            "result": null
                        })
                        return;
                    }
                    if (dbData1 && dbData1.length) {
                        cb(null, { "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": util.statusMessage.MOBILE_EXIST, "result": null });
                        return;
                    } else {
                        let criteria2 = {
                            email_id: data.email_id,
                            user_type: data.user_type
                        }
                        vendorDAO.getUsers(criteria2, (err, dbData2) => {
                            if (err) {
                                console.log(err)
                                cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                                return;
                            }
                            if (dbData2 && dbData2.length) {
                                cb(null, { "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": util.statusMessage.EMAIL_EXIST, "result": null });
                                return;
                            } else {
                                var vendorData = {
                                    "first_name": data.name ? data.name : '',
                                    "email_id": data.email_id ? data.email_id : '',
                                    "country_code": data.country_code ? data.country_code : '',
                                    "mobile_no": data.mobile_no ? data.mobile_no : '',
                                    "profile_pic": data.store_logo ? data.store_logo : '',
                                    "password": data.password ? util.encryptData(data.password) : '',
                                    "user_type": data.user_type ? data.user_type : 'vendor',
                                    "status": "0",
                                    "role": null,
                                }
                                vendorDAO.createUser(vendorData, (err, dbData) => {

                                    if (err) {
                                        cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
                                        return;
                                    } else {
                                        let criteria = {
                                            mobile_no: data.mobile_no,
                                            user_type: data.user_type,
                                            status: '0'
                                        }
                                        vendorDAO.getUsers(criteria, (err, dbData) => {
                                            if (err) {
                                                cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                                                return;
                                            }


                                            if (dbData && dbData.length) {
                                                var vendorDetails = {

                                                    "user_id": dbData[0].user_id,
                                                    "store_name": data.store_name ? data.store_name : '',
                                                    "store_type": data.store_type ? data.store_type : '0',
                                                    "store_address": data.store_address ? data.store_address : '',
                                                    "registration_number": data.registration_number ? data.registration_number : '',
                                                    "gstin_number": data.gstin_number ? data.gstin_number : '',
                                                    "currency": data.currency ? data.currency : '',
                                                    "minimum_order": data.minimum_order ? data.minimum_order : '',
                                                    "twitter_profile": data.twitter_profile ? data.twitter_profile : '',
                                                    "instagram_profile": data.instagram_profile ? data.instagram_profile : '',
                                                    "facebook_profile": data.facebook_profile ? data.facebook_profile : '',
                                                    "pan_card": data.pan_card ? data.pan_card : '',
                                                    "category_id": data.store_type ? data.store_type : '0',
                                                    "gst": data.gst ? data.gst : '',
                                                    "lat": data.lat ? data.lat : '0',
                                                    "lng": data.lng ? data.lng : '0',
                                                    "city": data.city ? data.city : '',
                                                    "pincode": data.pincode ? data.pincode : '0',
                                                    "description": ""
                                                }
                                                console.log(JSON.parse(data.open_days))
                                                JSON.parse(data.open_days).forEach(element => {
                                                    var timings = {
                                                        "user_id": dbData[0].user_id,
                                                        "day": element.day,
                                                        "open_time": element.open_time ? element.open_time : '00:00',
                                                        "close_time": element.close_time ? element.close_time : '00:00',
                                                        "status": element.open_time ? "1" : "0"
                                                    }
                                                    vendorDAO.createUserTimings(timings, (err, timeData) => {
                                                        if (err) {
                                                            console.log(err)
                                                            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                                                            return;
                                                        }
                                                    });
                                                });


                                                vendorDAO.createUserInfo(vendorDetails, (err, dbData1) => {
                                                    if (err) {
                                                        console.log(err)
                                                        cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                                                        return;
                                                    } else {
                                                        const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
                                                        dbData[0].token = token;
                                                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": util.statusMessage.USER_ADDED, "result": dbData[0] });
                                                    }

                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });

                    }
                });
            }
        },
        (err, response) => {
            cb(response.checkUserExistsinDB);
        })
}

/*  Login API */
let login = (data, callback) => {
    async.auto({
        checkUserExistsinDB: (cb) => {

            if (!data.username || !data.password) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }

            let criteria = {
                username: data.username,
                password: util.encryptData(data.password),
                user_type: data.user_type ? data.user_type : 'vendor'
            }
            vendorDAO.getUsersLogin(criteria, (err, dbData) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                }
                if (dbData && dbData.length) {

                    const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
                    dbData[0].token = token
                    cb(null, { "statusCode": util.statusCode.OK, "statusMessage": util.statusMessage.LOGIN_SUCCESS, "result": dbData[0] });
                } else {
                    cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.INCORRECT_CREDENTIALS, "result": null });
                }

            });
        }
    }, (err, response) => {
        callback(response.checkUserExistsinDB);
    })
}

/****** Get Profile API *****/
let getDetails = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token

    })
    let UserData = {
        user_id: userId
    }
    vendorDAO.getUserData(UserData, (err, dbData) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Profile Data", "result": dbData['0'] });
            return;
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist", "result": null });
            return;
        }
    });
}

// update device token
let updateDeviceToken = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.device_token && !data.device_type) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }
            var userId
            util.jwtDecode(headers.accesstoken, (err, token) => {
                userId = token
            })

            let criteria = {
                user_id: userId,
                status: '1'
            }
            vendorDAO.getUsers(criteria, (err, dbData) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.FOUR_ZERO_FOUR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
                    return;
                }
                if (dbData && dbData.length == 0) {
                    cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.INCORRECT_USER, "result": null });
                    return;
                } else {
                    let dataToSet = {
                        device_token: data.device_token,
                        device_type: data.device_type
                    }
                    vendorDAO.updateDeviceToken(criteria, dataToSet, (err, updateData) => {
                        if (err) {
                            cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                        }

                        vendorDAO.getUserData(criteria, (err, dbData) => {
                            console.log(err)
                            if (err) {
                                cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                                return;
                            }


                            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
                            dbData[0].token = token
                            if (data.type == 'LOGOUT') {
                                var msg = 'User logout successfully'
                            } else {
                                var msg = 'Device token updated successfully'
                            }

                            cb(null, { "statusCode": util.statusCode.OK, "statusMessage": msg, "result": dataToSet });
                        });
                    });
                }

            });
        }

    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/************ Update Profile ***********/
let updateProfile = (data, headers, cb) => {
    //console.log(data)
    async.auto({
            checkUserExistsinDB: (cb) => {

                var userId
                util.jwtDecode(headers.accesstoken, (err, token) => {
                    userId = token

                })
                let criteria = {
                    user_id: userId
                }


                let dataToSet = {
                    "user_id": userId,
                    "profile_json": JSON.stringify(data)
                }

                vendorDAO.updateProfile(dataToSet, (err, updateData) => {
                    if (err) {
                        cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })

                    } else {

                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": util.statusMessage.USER_UPDATED, "result": null });

                    }
                });
            }
        },
        (err, response) => {
            cb(response.checkUserExistsinDB);
        })
}


// update store timings
let updateStoreTimings = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.store_timings) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }
            var userId
            util.jwtDecode(headers.accesstoken, (err, token) => {
                userId = token
            })

            let criteria = {
                user_id: userId
            }
            vendorDAO.getUsers(criteria, (err, dbData) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.FOUR_ZERO_FOUR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
                    return;
                }
                if (dbData && dbData.length == 0) {
                    cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.INCORRECT_USER, "result": null });
                    return;
                } else {
                    JSON.parse(data.store_timings).forEach(element => {
                        let criteria1 = {
                            user_id: userId,
                            day: element.day,
                        }
                        var timings = {
                            "day": element.day,
                            "open_time": element.open_time,
                            "close_time": element.close_time,
                            "status": element.status
                        }
                        vendorDAO.updateStoreTimings(criteria1, timings, (err, updateData) => {
                            if (err) {
                                cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                            }
                        });

                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Updated Successfully", "result": data.store_timings });


                    });
                }

            });
        }

    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

// Add Delivery Charge
let addDeliveryCharge = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.base_delivery_charge && !data.delivery_charge_per_km) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }
            var userId
            util.jwtDecode(headers.accesstoken, (err, token) => {
                userId = token
            })

            let criteria = {
                user_id: userId
            }
            let dataToSet = {
                base_delivery_charge: data.base_delivery_charge,
                delivery_charge_per_km: data.delivery_charge_per_km
            }
            vendorDAO.addDeliveryCharge(criteria, dataToSet, (err, updateData) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                } else {
                    if (data.type == 'ADD') {
                        var msg = 'Delivery Charges added successfully'
                    } else {
                        var msg = 'Delivery Charges updated successfully'
                    }
                    cb(null, { "statusCode": util.statusCode.OK, "statusMessage": msg, "result": dataToSet });
                }
            });

        }

    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

// Add Delivery Executive
let addDeliveryExecutive = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.name && !data.country_code && !data.mobile_no && !data.image) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }
            var userId
            util.jwtDecode(headers.accesstoken, (err, token) => {
                userId = token
            })

            let dataToSet = {
                vendor_id: userId,
                full_name: data.name,
                country_code: data.country_code,
                mobile_no: data.mobile_no,
                image: data.image
            }
            vendorDAO.addDeliveryExecutive(dataToSet, (err, dbData) => {
                if (err) {
                    console.log(err);
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                } else {
                    cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Delivery Executive added successfully", "result": dataToSet });
                }
            });

        }

    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/****** Get Delivery API *****/
let getDeliveryDetails = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token

    })
    let UserData = {
        user_id: userId
    }
    vendorDAO.getVendorList(UserData, (err, dbData) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        } else {
            var result = {};
            vendorDAO.getDeliveryData(UserData, (err, dbData1) => {
                if (err) {
                    cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
                    return;
                }

                result['vendors'] = dbData;
                result['delivery_data'] = dbData1['0'];

                cb({ "statusCode": util.statusCode.OK, "statusMessage": "Delivery Data", "result": result });
                return;
            });
        }
    });
}

// Add Inventory
let addInventory = (data, headers, callback) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.service_type && !data.item_image && !data.item_category && !data.item_name && !data.description && !data.in_stock) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }
            var userId
            util.jwtDecode(headers.accesstoken, (err, token) => {
                userId = token
            })

            let dataToSet = {
                vendor_id: userId,
                service_type: data.service_type,
                item_image: data.item_image,
                category_id: data.item_category,
                name: data.item_name,
                description: data.description,
                in_stock: data.in_stock,
                eta: data.eta,
                subscription_type: data.subscription_type ? data.subscription_type : 'other',
                base_price: data.base_price ? data.base_price : '0'
            }

            vendorDAO.addInventory(dataToSet, (err, dbData) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                } else {

                    // data.variants.forEach(element => {

                    JSON.parse(data.variants).forEach(element => {
                        var variants = {
                            "item_id": dbData,
                            "unit_qty": element.unit_qty,
                            "unit_price": element.unit_price,
                            "unit_type": element.unit_type
                        }
                        vendorDAO.createVariants(variants, (err, dbData1) => {
                            if (err) {
                                cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                                return;
                            }
                        });
                    });
                    cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Inventory added successfully", "result": null });
                }
            });

        }

    }, (err, response) => {
        callback(response.checkUserExistsinDB);
    })
}


/****** Get Business Category API *****/
let getBusinessCategory = (data, cb) => {

    vendorDAO.getBusinessCategory((err, dbData) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        var result = {};
        if (dbData && dbData.length) {
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Business Category", "result": dbData });
            return;
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist", "result": null });
            return;
        }
    });
}


/****** Get Category API *****/
let getCategory = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token

    })
    let UserData = {
        user_id: userId
    }
    vendorDAO.getCategory(UserData, (err, dbData) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        var result = {};
        if (dbData && dbData.length) {
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Category List", "result": dbData });
            return;
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist", "result": null });
            return;
        }
    });
}

/****** Get Products API *****/
let getProducts = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token

    })
    let UserData = {
        user_id: userId
    }
    vendorDAO.getProducts(UserData, async(err, dbData) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        var result = {};
        for (var i = 0; dbData.length > i; i++) {
            var criteria = {
                item_id: dbData[i].id,
            }
            var variants = await getProductDataForUser(criteria)
            dbData[i]['variants'] = variants
        }
        if (dbData && dbData.length) {
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Products List", "result": dbData });
            return;
        } else {
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Products List", "result": dbData });
            return;
        }
    });
}


/****** Get Products Details API *****/
let getProductDetails = (data, headers, cb) => {
    if (!data.product_id) {
        cb({ "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
        return;
    }
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token

    })
    let productData = {
        product_id: data.product_id
    }
    vendorDAO.getProductDetails(productData, (err, dbData) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        } else {
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Products Data", "result": dbData['0'] });
            return;
        }
    });
}

// Update Inventory
let updateInventory = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.item_id && !data.service_type && !data.item_image && !data.item_category && !data.item_name && !data.in_stock) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }
            var userId
            util.jwtDecode(headers.accesstoken, (err, token) => {
                userId = token
            })

            let dataToSet = {
                vendor_id: userId,
                service_type: data.service_type,
                item_image: data.item_image,
                category_id: data.item_category,
                name: data.item_name,
                description: data.description ? data.description : '',
                in_stock: data.in_stock,
                eta: data.eta,
                subscription_type: data.subscription_type,
                base_price: data.base_price ? data.base_price : '0'
            }


            let criteria = {
                item_id: data.item_id,
            }

            vendorDAO.updateInventory(criteria, dataToSet, (err, dbData) => {
                //console.log(err)
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                } else {
                    //console.log(data.variants);
                    // data.variants.forEach(element => {
                    JSON.parse(data.variants).forEach(element => {
                        var variants = {
                            "item_id": data.item_id,
                            "unit_qty": element.unit_qty,
                            "unit_price": element.price,
                            "unit_type": element.unit_type
                        }
                        vendorDAO.createVariants(variants, (err, dbData1) => {
                            console.log(err)
                            if (err) {
                                cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                                return;
                            }
                        });
                    });
                    cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Inventory updated successfully", "result": null });
                }
            });

        }

    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}



/****** Get Orders List API *****/
let get_orders = (data, headers, cb) => {
    if (!data.type) {
        cb({ "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
        return;
    }
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token

    })
    let UserData = {
        user_id: userId
    }
    vendorDAO.getUsers(UserData, (err, dbData) => {
        if (err) {
            console.log(">>>>>>>>>>", err)
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR });
            return;
        }
        if (dbData && dbData.length) {
            if (data.type == 'past') {

                var criteria = {
                    user_id: userId,
                    order_status: 'delivered'
                }

            }
            if (data.type == 'active') {
                var criteria = {
                    user_id: userId,
                    order_status: 'active'
                }
            }

            vendorDAO.get_orders(criteria, (err, dbData1) => {
                if (err) {
                    // console.log(">>>>>>>>>>", err)
                    cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR });
                    return;
                } else {

                    cb({ "statusCode": util.statusCode.OK, "statusMessage": "Orders", "result": dbData1 });
                    return;

                }
            });

        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist" });
            return;
        }
    });
}

/****** Get Driver Order Detail Data API *****/
let get_order_detail = (data, headers, cb) => {
    if (!data.order_id) {
        cb({ "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
        return;
    }
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token

    })


    let criteria = {
        order_id: data.order_id
    }

    vendorDAO.get_order_details(criteria, (err, dbData1) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR });
            return;
        } else {
            let UserData = {
                user_id: dbData1['0'].user_id
            }
            vendorDAO.getUsers(UserData, (err, dbData) => {
                if (err) {
                    cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR });
                    return;
                }
                if (dbData && dbData.length) {
                    var result = {};
                    let user_data = {
                        'user_name': dbData['0'].first_name + ' ' + dbData['0'].last_name,
                        'profile': dbData['0'].profile_pic,
                        'email': dbData['0'].email_id,
                        'country_code': dbData['0'].country_code,
                        'mobile': dbData['0'].mobile_no,
                    }

                    result['order'] = dbData1;
                    result['user'] = user_data;

                    cb({ "statusCode": util.statusCode.OK, "statusMessage": "Orders", "result": result });
                    return;
                }
            });
        }
    });


}


/************ Update Delivery Mode ***********/
let updateDeliveryMode = (data, headers, cb) => {
    //console.log(data)
    async.auto({
            checkUserExistsinDB: (cb) => {

                var userId
                util.jwtDecode(headers.accesstoken, (err, token) => {
                    userId = token

                })
                let criteria = {
                    user_id: userId
                }


                let dataToSet = {
                    "user_id": userId,
                    "profile_json": JSON.stringify(data)
                }

                vendorDAO.updateDeliveryMode(dataToSet, (err, updateData) => {
                    if (err) {
                        cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })

                    } else {

                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": util.statusMessage.USER_UPDATED, "result": null });

                    }
                });
            }
        },
        (err, response) => {
            cb(response.checkUserExistsinDB);
        })
}


/************ Change Order Status ***********/
let changeOrderStatus = (data, headers, cb) => {
    //console.log(data)
    async.auto({
            checkUserExistsinDB: (cb) => {

                var userId
                util.jwtDecode(headers.accesstoken, (err, token) => {
                    userId = token

                })
                let criteria = {
                    "order_id": data.order_id
                }

                let dataToSet = {
                    "order_status": data.order_status
                }

                vendorDAO.changeOrderStatus(dataToSet, criteria, (err, updateData) => {
                    if (err) {
                        cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })

                    } else {

                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": util.statusMessage.ORDER_STATUS_UPDATED, "result": dataToSet });

                    }
                });
            }
        },
        (err, response) => {
            cb(response.checkUserExistsinDB);
        })
}


/************ Reset Password ***********/
let resetPassword = (data, cb) => {
    if (!data.mobile_no || !data.password) {
        cb({ "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
        return;
    }
    let criteria = {
        mobile_no: data.mobile_no,
        user_type: data.user_type
    }

    let dataToSet = {
        "password": util.encryptData(data.password)
    }

    vendorDAO.updatePassword(dataToSet, criteria, (err, updateData) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })

        } else {

            cb({ "statusCode": util.statusCode.OK, "statusMessage": util.statusMessage.PASSWORD_UPDATED, "result": null });

        }
    });

}



module.exports = {
    checkMobile: checkMobile,
    checkEmail: checkEmail,
    signup: signup,
    login: login,
    getDetails: getDetails,
    updateDeviceToken: updateDeviceToken,
    updateProfile: updateProfile,
    updateStoreTimings: updateStoreTimings,
    addDeliveryCharge: addDeliveryCharge,
    addDeliveryExecutive: addDeliveryExecutive,
    getDeliveryDetails: getDeliveryDetails,
    addInventory: addInventory,
    getBusinessCategory: getBusinessCategory,
    getCategory: getCategory,
    getProducts: getProducts,
    getProductDetails: getProductDetails,
    updateInventory: updateInventory,
    get_orders: get_orders,
    get_order_detail: get_order_detail,
    updateDeliveryMode: updateDeliveryMode,
    changeOrderStatus: changeOrderStatus,
    resetPassword: resetPassword
}

async function getProductDataForUser(data) {
    return new Promise((resolve, reject) => {
        // let conditions = "";
        // data.item_id ? conditions += `item_id = '${data.item_id}'` : true;
        //data.userId ? conditions += `userId ='${data.userId}'` : true;
        var query = `SELECT v.unit_type,v.unit_qty,ROUND(v.unit_price,2) as price FROM s_inventory as p JOIN s_inventory_variants as v ON p.id = v.item_id  WHERE p.id = ${data.item_id} AND p.status = "1" `

        dbConfig.getDB().query(query, (err3, dbData3) => {
            if (err3) {
                reject(err3);
            } else {
                resolve(dbData3)
            }
        })

    })
}