/*
 * @Author: Hitesh
 * @Date: May 3, 2021
 */

let async = require('async'),
    jwt = require('jsonwebtoken');
// let Json2csvParser = require("json2csv").Parser;
let createCsvWriter = require("csv-writer").createObjectCsvWriter;
let dbConfig = require("../Utilities/dbConfig");

let util = require('../Utilities/util'),
    config = require('../Utilities/Config'),
    adminDAO = require('../DAO/adminDAO');

    /*  Login API */
let login = (data, callback) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.email_id || !data.password) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }

            let criteria = {
                email_id: data.email_id,
                password: util.encryptData(data.password),
            }
            adminDAO.getAdminLogin(criteria, (err, dbData) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                }
                if (dbData && dbData.length) {
                    const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
                    dbData[0].token = token
                    cb(null, { "statusCode": util.statusCode.OK, "statusMessage": util.statusMessage.LOGIN_SUCCESS, "result": dbData[0] });
                } else {
                    cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.INCORRECT_CREDENTIALS, "result": null });
                }
            });
        }
    }, (err, response) => {
        callback(response.checkUserExistsinDB);
    })
}

/************ Update Vendor ***********/
let updateVendor = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.status || !data.id) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
                return;
            }
            var email
            util.jwtDecode(headers.accesstoken, (err, token) => {
                email = token
            })

            let criteria = {
                id: data.id,
            }
            let dataToSet = {
                status: data.status     //Enabled when status:'1', Disabled when status:'0", Soft delete when status:'2'
            }

            adminDAO.updateVendor(criteria, dataToSet, (err, data) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })

                } else {
                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Vendor Updated"});
                }
            });
        }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/**** Add Vendor Category ****/
let addVendorCategory = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.image && !data.category_name) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }
            var userId
            util.jwtDecode(headers.accesstoken, (err, token) => {
                userId = token
            })

            let dataToSet = {
                // id: userId,
                category_name: data.category_name,
                image: data.image
            }
            adminDAO.addVendorCategory(dataToSet, (err, dbData) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                } else {
                    cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Vendor Category added successfully", "result": dataToSet });
                }
            });
        }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/****** Get Vendor Category List API *****/
let getVendorCategory = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.getVendorCategory(UserData, (err, dbData) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        var result = {};
        if (dbData && dbData.length) {
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Vendor Category", "result": dbData });
            return;
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist", "result": null });
            return;
        }
    });
}

/************ Edit Vendor Category ***********/
let editVendorCategory = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.id) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
                return;
            }
            var email
            util.jwtDecode(headers.accesstoken, (err, token) => {
                email = token
            })

            let criteria = {
                id: data.id,
            }
            let dataToSet = {
                category_name: data.category_name,
                image: data.image
            }

            adminDAO.editVendorCategory(criteria, dataToSet, (err, data) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })
                } else {
                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Vendor Category Edited"});
                }
            });
        }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/************ Update Product ***********/
let updateProduct = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.status || !data.id) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
                return;
            }
            var email
            util.jwtDecode(headers.accesstoken, (err, token) => {
                email = token
            })

            let criteria = {
                id: data.id,
            }
            let dataToSet = {
                status: data.status     //Enabled when status:'1', Disabled when status:'0", Soft delete when status:'2'
            }

            adminDAO.updateProduct(criteria, dataToSet, (err, data) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })

                } else {
                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Product Updated"});
                }
            });
        }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/**** Add Product Category ****/
let addProductCategory = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.name && !data.description) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }
            var userId
            util.jwtDecode(headers.accesstoken, (err, token) => {
                userId = token
            })

            let dataToSet = {
                // id: userId,
                name: data.name,
                category_image: data.category_image,
                description: data.description
            }
            adminDAO.addProductCategory(dataToSet, (err, dbData) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                } else {
                    cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Product Category added successfully", "result": dataToSet });
                }
            });
        }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/****** Get Product Category List API *****/
let getProductCategory = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.getProductCategory(UserData, (err, dbData) => {
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Product Category", "result": dbData });
            return;
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist", "result": null });
            return;
        }
    });
}

/************ Edit Product Category ***********/
let editProductCategory = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.id) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
                return;
            }
            var email
            util.jwtDecode(headers.accesstoken, (err, token) => {
                email = token
            })

            let criteria = {
                id: data.id,
            }
            let dataToSet = {
                name: data.name,
                category_image: data.category_image,
                description: data.description
            }

            adminDAO.editProductCategory(criteria, dataToSet, (err, data) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })

                } else {
                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Product Category Edited"});
                }
            });
        }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/****** Get Active Stores API *****/
let getActiveStores = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.getActiveStores(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Active Stores Data", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "No Active Stores", "result": null });
            return;
        }
    });
}

/****** Export Active Stores Listing *****/
let exportActiveStores = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId,
    }
    adminDAO.exportActiveStores(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            
            const csvWriter = createCsvWriter({
                path: "ActiveStores_Data.csv",
                header: [
                  { id: "vendor_id", title: "Vendor Id" },
                  { id: "store_name", title: "Store Name" },
                  { id: "registration_number", title: "Registration Number" },
                  { id: "mobile_no", title: "Mobile Number" },
                  { id: "category_name", title: "Store Category" },
                  { id: "store_address", title: "Store Address" }
                ]
              });
            csvWriter
                .writeRecords(dbData)
                .then(() =>
                        console.log("Write to ActiveStores_Data.csv successfully!")
                    );

            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Excel file downloaded!"});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist", "result": null });
            return;
        }
    });
}

/****** Get New Stores API *****/
let getNewStores = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.getNewStores(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token;
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "New Stores Data", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "No New Store", "result": null });
            return;
        }
    });
}

/****** Export New Stores Listing *****/
let exportNewStores = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.exportNewStores(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            
            const csvWriter = createCsvWriter({
                path: "NewStores_Data.csv",
                header: [
                    { id: "vendor_id", title: "Vendor Id" },
                    { id: "store_name", title: "Store Name" },
                    { id: "registration_number", title: "Registration Number" },
                    { id: "mobile_no", title: "Mobile Number" },
                    { id: "category_name", title: "Store Category" },
                    { id: "store_address", title: "Store Address" }
                ]
              });
            csvWriter
                .writeRecords(dbData)
                .then(() =>
                        console.log("Write to NewStores_Data.csv successfully!")
                    );

            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Excel file downloaded!"});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "No Data Found", "result": null });
            return;
        }
    });
}

/************ Approve New Store ***********/
let approveStore = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.user_id) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
                return;
            }
            var email
            util.jwtDecode(headers.accesstoken, (err, token) => {
                email = token
            })

            let criteria = {
                user_id: data.user_id,
            }
            // let dataToSet = {
            //     status: data.status     //Approve when status:'1', Pending for Approval when status:'0", Reject when status:'2'
            // }

            adminDAO.approveStore(criteria, /*dataToSet,*/ (err, data) => {
                console.log(err)
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })
                } else {
                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Store Approved"});
                }
            });
        }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/****** Get Update Request API *****/
let getUpdateRequest = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.getUpdateRequest(UserData, (err, dbData) => {
        console.log(err)

        let result = []
        dbData.forEach(function(data, index) {
            result.push(dbData[index].user_id, JSON.parse(dbData[index].profile_json))
        });

        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Update Request Data", "result": result});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist", "result": null });
            return;
        }
    });
}

/************ Approve Update Request ***********/
let approveUpdateRequest = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.user_id) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
                return;
            }
            var email
            util.jwtDecode(headers.accesstoken, (err, token) => {
                email = token
            })

            let criteria = {
                user_id: data.user_id,
            }

            adminDAO.getUpdateReq(criteria, (err, dbData) => {
                console.log(err)
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR });
                    return;
                }
                else{
                    if(dbData && dbData.length){
                        updated_data = {
                            'user_id': dbData['0'].user_id,
                            'store_name': (JSON.parse(dbData['0'].profile_json)).store_name,
                            'email_id': (JSON.parse(dbData['0'].profile_json)).email_id,
                            'country_code': (JSON.parse(dbData['0'].profile_json)).country_code,
                            'mobile_no': (JSON.parse(dbData['0'].profile_json)).mobile_no,
                            'store_address': (JSON.parse(dbData['0'].profile_json)).store_address,
                            'minimun_order': (JSON.parse(dbData['0'].profile_json)).minimun_order,
                            'twitter_profile': (JSON.parse(dbData['0'].profile_json)).twitter_profile,
                            'instagram_profile': (JSON.parse(dbData['0'].profile_json)).instagram_profile,
                            'facebook_profile': (JSON.parse(dbData['0'].profile_json)).facebook_profile,
                            'profile_pic': (JSON.parse(dbData['0'].profile_json)).profile_pic,
                            'registration_number': (JSON.parse(dbData['0'].profile_json)).registration_number,
                            'gstin_number': (JSON.parse(dbData['0'].profile_json)).gstin_number,
                            'store_type': (JSON.parse(dbData['0'].profile_json)).store_type,
                            'currency': (JSON.parse(dbData['0'].profile_json)).currency,
                            'delivery_mode': (JSON.parse(dbData['0'].profile_json)).delivery_mode,
                        }
                    }

            let dataToSet = {
                store_name: updated_data.store_name,
                email_id: updated_data.email_id,
                country_code: updated_data.country_code,
                mobile_no: updated_data.mobile_no,
                store_address: updated_data.store_address,
                minimun_order: updated_data.minimun_order,
                twitter_profile: updated_data.twitter_profile,
                instagram_profile: updated_data.instagram_profile,
                facebook_profile: updated_data.facebook_profile,
                profile_pic: updated_data.profile_pic,
                registration_number: updated_data.registration_number,
                gstin_number: updated_data.gstin_number,
                store_type: updated_data.store_type,
                currency: updated_data.currency,
                delivery_mode: updated_data.delivery_mode,
            }

            adminDAO.approveUpdateRequest(criteria, dataToSet, (err, data) => {
                console.log(err)
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })
                } else {
                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Update Request Approved"});
                }
            });
                }
        });
        }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/****** Export Update Request Listing *****/
let exportUpdateRequest = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.exportUpdateRequest(UserData, (err, dbData) => {
        console.log(err)
        let result = []
        dbData.forEach(function(data, index) {
            result.push(JSON.parse(dbData[index].profile_json))
        });
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            
            const csvWriter = createCsvWriter({
                path: "UpdateRequest_Data.csv",
                header: [
                    { id: "vendor_id", title: "Vendor Id" },
                    { id: "store_name", title: "Store Name" },
                    { id: "email_id", title: "Email Id" },
                    { id: "mobile_no", title: "Mobile Number" },
                    { id: "store_address", title: "Store Address" }
                ]
              });
            csvWriter
                .writeRecords(result)
                .then(() =>
                        console.log("Write to UpdateRequest_Data.csv successfully!")
                    );

            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Excel file downloaded!"});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "No Data Found", "result": null });
            return;
        }
    });
}

/****** Get Store Details of Active Store API *****/
let activeStoreDetails = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId,
        vendor_id: data.vendor_id
    }
    adminDAO.activeStoreDetails(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Store Details of Active Store", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "Store Not Exist", "result": null });
            return;
        }
    });
}

/****** Get Documents of Active Store API *****/
let activeStoreDocuments = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId,
        vendor_id: data.vendor_id
    }
    adminDAO.activeStoreDocuments(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Documents of Active Store", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "Store Not Exist", "result": null });
            return;
        }
    });
}

/****** Get Inventory of Active Stores API *****/
let activeStoreInventory = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId,
        vendor_id: data.vendor_id 
    }
    adminDAO.activeStoreInventory(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Inventory of Active Store", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "No Inventory for Selected Store", "result": null });
            return;
        }
    });
}

/****** Get Orders of Active Store API *****/
let activeStoreOrders = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId,
        vendor_id: data.vendor_id
    }
    adminDAO.activeStoreOrders(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Orders of Active Store", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "No Orders for Selected Vendor", "result": null });
            return;
        }
    });
}

/****** Get Customer Listing *****/
let getCustomers = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.getCustomers(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Customers List", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist", "result": null });
            return;
        }
    });
}

/****** Export Customer Listing *****/
let exportCustomers = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.exportCustomers(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            
            const csvWriter = createCsvWriter({
                path: "Customer_Data.csv",
                header: [
                  { id: "user_id", title: "user_id" },
                  { id: "first_name", title: "first_name" },
                  { id: "last_name", title: "last_name" },
                  { id: "email_id", title: "email_id" },
                  { id: "mobile_no", title: "mobile_no" },
                  { id: "date_of_birth", title: "date_of_birth" },
                  { id: "gender", title: "gender" },
                  { id: "referal_code", title: "referal_code" },
                  { id: "wallet", title: "wallet" },
                  { id: "points", title: "points" }
                ]
              });
            csvWriter
                .writeRecords(dbData)
                .then(() =>
                        console.log("Write to Customer_Data.csv successfully!")
                    );

            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Excel file downloaded!"});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist", "result": null });
            return;
        }
    });
}

/****** Get Customer Personal Details *****/
let getCustomerDetails = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user: userId,
        user_id: data.user_id
    }
    adminDAO.getCustomerDetails(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Customer Personal Details", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "Customer Not Exist", "result": null });
            return;
        }
    });
}

/****** Get Customer Orders *****/
let getCustomerOrders = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user: userId,
        user_id: data.user_id
    }
    adminDAO.getCustomerOrders(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Customer Orders List", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "No Orders for Selected Customer", "result": null });
            return;
        }
    });
}

/****** Get Active Orders List *****/
let getActiveOrders = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user: userId
    }
    adminDAO.getActiveOrders(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Active Orders List", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "No Active Orders", "result": null });
            return;
        }
    });
}

/****** Export Active Orders Listing to Excel *****/
let exportActiveOrders = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.exportActiveOrders(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            
            const csvWriter = createCsvWriter({
                path: "ActiveOrders_Data.csv",
                header: [
                  { id: "order_unique_id", title: "Order ID" },
                  { id: "first_name", title: "First Name" },
                  { id: "last_name", title: "Last Name" },
                  { id: "mobile_no", title: "Mobile Number" },
                  { id: "address", title: "Delivery Address" },
                  { id: "order_price", title: "Amount" },
                  { id: "store_name", title: "Vendor Name" },
                  { id: "added_on", title: "Date of Order" },
                  { id: "order_status", title: "Status" }
                ]
              });
            csvWriter
                .writeRecords(dbData)
                .then(() =>
                        console.log("Write to ActiveOrders_Data.csv successfully!")
                    );

            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Excel file downloaded!"});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "Data Not Found", "result": null });
            return;
        }
    });
}

/****** Get Delivered Orders List *****/
let getDeliveredOrders = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user: userId
    }
    adminDAO.getDeliveredOrders(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Delivered Orders List", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "No Delivered Orders", "result": null });
            return;
        }
    });
}

/****** Export Delivered Orders Listing to Excel *****/
let exportDeliveredOrders = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.exportDeliveredOrders(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            
            const csvWriter = createCsvWriter({
                path: "DeliveredOrders_Data.csv",
                header: [
                  { id: "order_unique_id", title: "Order ID" },
                  { id: "first_name", title: "First Name" },
                  { id: "last_name", title: "Last Name" },
                  { id: "mobile_no", title: "Mobile Number" },
                  { id: "address", title: "Delivery Address" },
                  { id: "order_price", title: "Amount" },
                  { id: "store_name", title: "Vendor Name" },
                  { id: "added_on", title: "Date of Order" },
                  { id: "order_status", title: "Status" }
                ]
              });
            csvWriter
                .writeRecords(dbData)
                .then(() =>
                        console.log("Write to DeliveredOrders_Data.csv successfully!")
                    );

            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Excel file downloaded!"});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "Data Not Found", "result": null });
            return;
        }
    });
}

/****** Get Cancelled Orders List *****/
let getCancelledOrders = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user: userId
    }
    adminDAO.getCancelledOrders(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Cancelled Orders List", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "No Cancelled Orders", "result": null });
            return;
        }
    });
}

/****** Export Cancelled Orders Listing to Excel *****/
let exportCancelledOrders = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.exportCancelledOrders(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            
            const csvWriter = createCsvWriter({
                path: "CancelledOrders_Data.csv",
                header: [
                  { id: "order_unique_id", title: "Order ID" },
                  { id: "first_name", title: "First Name" },
                  { id: "last_name", title: "Last Name" },
                  { id: "mobile_no", title: "Mobile Number" },
                  { id: "address", title: "Delivery Address" },
                  { id: "order_price", title: "Amount" },
                  { id: "store_name", title: "Vendor Name" },
                  { id: "added_on", title: "Date of Order" },
                  { id: "order_status", title: "Status" }
                ]
              });
            csvWriter
                .writeRecords(dbData)
                .then(() =>
                        console.log("Write to CancelledOrders_Data.csv successfully!")
                    );

            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Excel file downloaded!"});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "Data Not Found", "result": null });
            return;
        }
    });
}

/****** Get Details of Active Orders *****/
let activeOrderDetails = (data, headers, cb) => {
    if (!data.order_id) {
        cb({ "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
        return;
    }
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token

    })
    let criteria = {
        order_id: data.order_id
    }

    adminDAO.activeOrderDetails(criteria, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR });
            return;
        } else {
            let UserData = {
                user_id: dbData['0'].user_id
            }
            let VendorData = {
                vendor_id: dbData['0'].vendor_id
            }
            adminDAO.getUsers(UserData, (err, dbData1) => {
                console.log(err)
                if (err) {
                    cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR });
                    return;
                }
                if (dbData1 && dbData1.length) {       
                    let user_data = {
                        'user_id': dbData1['0'].user_id,
                        'user_name': dbData1['0'].first_name + ' ' + dbData1['0'].last_name,
                    }

                    adminDAO.getStoreDetails(VendorData, (err, dbData2) => {
                        console.log(err)
                        if (err) {
                            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR });
                            return;
                        }
                        if (dbData2 && dbData2.length){       
                            let vendor_data = {
                                'store_id': dbData2['0'].vendor_id,
                                'store_name': dbData2['0'].store_name,
                                'store_mobile_number': dbData2['0'].mobile_no,
                                'store_address': dbData2['0'].store_address
                            }
                            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Order Details", "result": dbData,  "user": user_data, "vendor": vendor_data });
                            return;
                        }
                    });
                }
            });
        }
    });
}

/**** Add Promotion Banner ****/
let addBanner = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.banner_title && !data.start_date && !data.end_date && !data.banner_path && !data.banner_image && !data.banner_priority && (!data.vendor_id || !data.external_url) ) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }
            var userId
            util.jwtDecode(headers.accesstoken, (err, token) => {
                userId = token
            })

            let vendor_id = 0;

            if(data.vendor_id && data.vendor_id != '' && !data.vendor_id  != null){
            vendor_id = data.vendor_id;
            }

            let criteria = {
                vendor_id: vendor_id
            }
            var vendor_data = []
            
            
            adminDAO.getStoreDetails(criteria, (err, dbData) => {
                console.log(err)
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR });
                    return;
                }
                else{
                    if(dbData && dbData.length){
                        vendor_data = {
                            'store_id': dbData['0'].user_id ? dbData['0'].user_id : 0,
                            'store_name': dbData['0'].store_name ? dbData['0'].store_name : "",
                            'lat': dbData['0'].lat ? dbData['0'].lat : "",
                            'lng': dbData['0'].lng ? dbData['0'].lng : ""
                        }
                    }
                    let dataToSet = {
                            // id: userId,
                            banner_title: data.banner_title,
                            banner_type: data.banner_type,
                            vendor_id: vendor_data.store_id ? vendor_data.store_id : "",
                            start_date: data.start_date,
                            end_date: data.end_date,
                            banner_path: data.banner_path,
                            latitude: vendor_data.lat ? vendor_data.lat : "",
                            longitude: vendor_data.lng ? vendor_data.lng : "",
                            distance: data.distance ? data.distance : "",
                            banner_priority: data.banner_priority,
                            discount_type: data.discount_type ? data.discount_type: "",
                            discount_value: data.discount_value ? data.discount_value : "",
                            min_order_value: data.min_order_value ? data.min_order_value : "",
                            description: data.description ? data.description : "",
                            banner_image: data.banner_image,
                            external_url: data.external_url ? data.external_url : ""
                        }
                        
                        adminDAO.addBanner(dataToSet, (err, dbData1) => {
                            console.log(err)
                            if (err) {
                                cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                            } else {
                                cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Banner added successfully", "result": dataToSet });
                            }
                        });
                    }
                });
            }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/****** Get Promotions List *****/
let getPromotions = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user: userId
    }
    adminDAO.getPromotions(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Promotions List", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "No Active Promotion", "result": null });
            return;
        }
    });
}

/************ Delete Promotion Banner ***********/
let deleteBanner = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.id) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
                return;
            }
            var email
            util.jwtDecode(headers.accesstoken, (err, token) => {
                email = token
            })

            let criteria = {
                id: data.id,
            }

            adminDAO.deleteBanner(criteria, (err, data) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })

                } else {
                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Banner Deleted"});
                }
            });
        }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/************ Edit Promotion Banner ***********/
let editBanner = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.id) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
                return;
            }
            var email
            util.jwtDecode(headers.accesstoken, (err, token) => {
                email = token
            })

            let criteria = {
                id: data.id,
            }
            let dataToSet = {
                banner_title: data.banner_title,
                description: data.description,
                start_date: data.start_date,
                end_date: data.end_date,
                banner_image: data.banner_image,
                banner_path: data.banner_path,
                distance: data.distance,
                banner_priority: data.banner_priority,
                discount_type: data.discount_type,
                discount_value: data.discount_value,
                min_order_value: data.min_order_value
            }

            adminDAO.editBanner(criteria, dataToSet, (err, data) => {
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })
                } else {
                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Banner Updated!"});
                }
            });
        }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

// Add Delivery Boy
let addDeliveryBoy = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.first_name && !data.country_code && !data.mobile_no) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING, "result": null })
                return;
            }
            var userId
            util.jwtDecode(headers.accesstoken, (err, token) => {
                userId = token
            })

            let dataToSet = {
                // vendor_id: userId,
                first_name: data.first_name,
                last_name: data.last_name,
                country_code: data.country_code,
                mobile_no: data.mobile_no,
                user_type: 'driver',
                status: '1'
            }
            adminDAO.addDeliveryBoy(dataToSet, (err, dbData) => {
                if (err) {
                    console.log(err);
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                } 
                // else {
                //     cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Delivery Boy added successfully", "result": dataToSet });
                // }

                else {
                    let criteria = {
                        mobile_no: data.mobile_no,
                        user_type: 'driver'
                    }
                    adminDAO.getUsers(criteria, (err, dbData) => {
                        if (err) {
                            cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                            return;
                        }

                        else if (dbData && dbData.length) {
                            var driverDocs = {
                                "user_id": dbData[0].user_id,
                                "document_name": data.document_name ? data.document_name : '',
                                "document_image": data.document_image ? data.document_image : '',
                            }

                            adminDAO.addDeliveryBoyDocs(driverDocs, (err, dbData1) => {
                                if (err) {
                                    console.log(err)
                                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null })
                                    return;
                                } else {
                                    // const token = jwt.sign({ id: dbData1[0].user_id }, 'SERVICE_KART', {})
                                    // dbData[0].token = token;
                                    cb(null, { "statusCode": util.statusCode.OK, "statusMessage": util.statusMessage.USER_ADDED, "result": dbData1[0] });
                                }

                            });
                        }
                    });
                }

            });

        }

    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}

/****** Get Delivery Boys Listing API *****/
let getDrivers = (data, headers, cb) => {
    if (!data.status) {
        cb({ "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
        return;
    }
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token

    })
    let UserData = {
        user_id: userId
    }
    vendorDAO.getUsers(UserData, (err, dbData) => {
        if (err) {
            console.log(">>>>>>>>>>", err)
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR });
            return;
        }
        if (dbData && dbData.length) {
            if (data.status == 'active') {

                var criteria = {
                    user_id: userId,
                    status: 'active'
                }

            }
            if (data.status == 'new') {
                var criteria = {
                    user_id: userId,
                    status: 'new'
                }
            }

            adminDAO.getDrivers(criteria, (err, dbData1) => {
                if (err) {
                    console.log(">>>>>>>>>>", err)
                    cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR });
                    return;
                } else {
                    cb({ "statusCode": util.statusCode.OK, "statusMessage": "Drivers", "result": dbData1 });
                    return;
                }
            });
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist" });
            return;
        }
    });
}

/****** Export Active Drivers Listing to Excel *****/
let exportActiveDrivers = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.exportActiveDrivers(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            
            const csvWriter = createCsvWriter({
                path: "ActiveDrivers_Data.csv",
                header: [
                  { id: "user_id", title: "Delivery Boy ID" },
                  { id: "first_name", title: "First Name" },
                  { id: "last_name", title: "Last Name" },
                  { id: "mobile_no", title: "Mobile Number" },
                  { id: "added_on", title: "Date of Joining" },
                  { id: "status", title: "Status" }
                ]
              });
            csvWriter
                .writeRecords(dbData)
                .then(() =>
                        console.log("Write to ActiveDrivers_Data.csv successfully!")
                    );

            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Excel file downloaded!"});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "Data Not Found", "result": null });
            return;
        }
    });
}

/****** Export New Drivers Listing to Excel *****/
let exportNewDrivers = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId
    }
    adminDAO.exportNewDrivers(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            
            const csvWriter = createCsvWriter({
                path: "NewDrivers_Data.csv",
                header: [
                  { id: "user_id", title: "Delivery Boy ID" },
                  { id: "first_name", title: "First Name" },
                  { id: "last_name", title: "Last Name" },
                  { id: "mobile_no", title: "Mobile Number" },
                  { id: "added_on", title: "Date of Joining" },
                  { id: "status", title: "Status" }
                ]
              });
            csvWriter
                .writeRecords(dbData)
                .then(() =>
                        console.log("Write to NewDrivers_Data.csv successfully!")
                    );

            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Excel file downloaded!"});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "Data Not Found", "result": null });
            return;
        }
    });
}

/************ Approve New Driver ***********/
let approveNewDriver = (data, headers, cb) => {
    async.auto({
        checkUserExistsinDB: (cb) => {
            if (!data.user_id) {
                cb(null, { "statusCode": util.statusCode.BAD_REQUEST, "statusMessage": util.statusMessage.PARAMS_MISSING })
                return;
            }
            var email
            util.jwtDecode(headers.accesstoken, (err, token) => {
                email = token
            })

            let criteria = {
                user_id: data.user_id,
            }
            // let dataToSet = {
            //     status: data.status     //Approve when status:'1', Pending for Approval when status:'0", Reject when status:'2'
            // }

            adminDAO.approveNewDriver(criteria, /*dataToSet,*/ (err, data) => {
                console.log(err)
                if (err) {
                    cb(null, { "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR })
                } else {
                        cb(null, { "statusCode": util.statusCode.OK, "statusMessage": "Store Approved"});
                }
            });
        }
    }, (err, response) => {
        cb(response.checkUserExistsinDB);
    })
}


/****** Search *****/
/*let search = (data, headers, cb) => {
    var userId
    util.jwtDecode(headers.accesstoken, (err, token) => {
        userId = token
    })
    let UserData = {
        user_id: userId,
        email_id: data.email_id,
        first_name: data.first_name,
        last_name: data.last_name
    }
    adminDAO.search(UserData, (err, dbData) => {
        console.log(err)
        if (err) {
            cb({ "statusCode": util.statusCode.INTERNAL_SERVER_ERROR, "statusMessage": util.statusMessage.DB_ERROR, "result": null });
            return;
        }
        if (dbData && dbData.length) {
            const token = jwt.sign({ id: dbData[0].user_id }, 'SERVICE_KART', {})
            dbData[0].token = token
            cb({ "statusCode": util.statusCode.OK, "statusMessage": "Data Found", "result": dbData});
        } else {
            cb({ "statusCode": util.statusCode.FOUR_ZERO_ZERO, "statusMessage": "User Not Exist", "result": null });
            return;
        }
    });
}*/


module.exports = {
    login: login,
    updateVendor: updateVendor,
    addVendorCategory: addVendorCategory,
    getVendorCategory: getVendorCategory,
    editVendorCategory: editVendorCategory,
    updateProduct: updateProduct,
    addProductCategory: addProductCategory,
    getProductCategory: getProductCategory,
    editProductCategory: editProductCategory,
    getActiveStores: getActiveStores,
    exportActiveStores: exportActiveStores,
    getNewStores: getNewStores,
    exportNewStores: exportNewStores,
    approveStore: approveStore,
    getUpdateRequest: getUpdateRequest,
    approveUpdateRequest: approveUpdateRequest,
    exportUpdateRequest: exportUpdateRequest,
    activeStoreDetails: activeStoreDetails,
    activeStoreDocuments: activeStoreDocuments,
    activeStoreInventory: activeStoreInventory,
    activeStoreOrders: activeStoreOrders,
    getCustomers: getCustomers,
    exportCustomers: exportCustomers,
    getCustomerDetails: getCustomerDetails,
    getCustomerOrders: getCustomerOrders,
    getActiveOrders: getActiveOrders,
    exportActiveOrders: exportActiveOrders,
    getDeliveredOrders: getDeliveredOrders,
    exportDeliveredOrders: exportDeliveredOrders,
    getCancelledOrders: getCancelledOrders,
    exportCancelledOrders: exportCancelledOrders,
    activeOrderDetails: activeOrderDetails,
    addBanner: addBanner,
    getPromotions: getPromotions,
    deleteBanner: deleteBanner,
    editBanner: editBanner,
    addDeliveryBoy: addDeliveryBoy,
    getDrivers: getDrivers,
    exportActiveDrivers: exportActiveDrivers,
    exportNewDrivers: exportNewDrivers,
    approveNewDriver: approveNewDriver,
    // search: search
}