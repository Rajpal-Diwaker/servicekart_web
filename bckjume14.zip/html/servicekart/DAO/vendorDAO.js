'use strict';

let dbConfig = require("../Utilities/dbConfig");
let qb = require("../Utilities/dbConfig").qb;


/**** Create User *****/
let createUser = (dataToSet, callback) => {
        dbConfig.getDB().query("insert into s_users set ? ", dataToSet, callback);
    }
    /**** Create User Info *****/
let createUserInfo = (dataToSet, callback) => {
        dbConfig.getDB().query("insert into s_vendors set ? ", dataToSet, callback);
    }
    /**** Create User Info *****/
let createUserTimings = (dataToSet, callback) => {
    dbConfig.getDB().query("insert into s_vendor_timings set ? ", dataToSet, callback);
}

/**** Get User Information *****/
let getUsers = (criteria, callback) => {
    let conditions = "";

    if (criteria.email_id) {
        criteria.email_id ? conditions += `u.email_id = '${criteria.email_id}'` : true;
    }
    if (criteria.mobile_no) {
        criteria.mobile_no ? conditions += `u.mobile_no = '${criteria.mobile_no}'` : true;
    }
    if (criteria.user_id) {
        criteria.user_id ? conditions += `u.user_id = '${criteria.user_id}'` : true;
    }

    criteria.user_type ? conditions += `and u.user_type = '${criteria.user_type}'` : true;
    criteria.status ? conditions += ` and status = '${criteria.status}'` : true;
    dbConfig.getDB().query(`select u.*,IF((SELECT COUNT(address_id) from s_user_address where user_id = u.user_id )>0,'1','0')as is_address from s_users as u where ${conditions}`, callback);


    // console.log(`select u.*,IF((SELECT COUNT(address_id) from s_user_address where user_id = u.user_id )>0,'1','0')as is_address from s_users as u where ${conditions}`)

}


/**** Get User Data *****/

let getUserData = (criteria, callback) => {
    let conditions = "";
    let ress = [];
    criteria.user_id ? conditions += `u.user_id = '${criteria.user_id}'` : true;
    criteria.status ? conditions += ` and u.status = '${criteria.status}'` : true;
    dbConfig.getDB().query(`select u.*,v.*,c.category_name from s_users as u left join s_vendors as v on u.user_id = v.user_id left join s_business_category as c on c.id= v.category_id where ${conditions}`, function(err, res) {
        if (err) {
            callback(err, null)
        } else {
            if (res.length > 0) {
                dbConfig.getDB().query(`SELECT u.day,u.open_time,u.close_time,u.status from s_vendor_timings as u  where user_id = ${criteria.user_id}`, function(err, res1) {
                    res['0'].timings = res1 ? res1 : '';
                    callback(null, res);
                });
            } else {
                callback(null, ress);
            }

        }
    });


}

/**** Get User Login Data *****/

let getUsersLogin = (criteria, callback) => {
    let conditions = "";

    criteria.username ? conditions += `(email_id = '${criteria.username}' OR mobile_no = '${criteria.username}')` : true;
    criteria.password ? conditions += ` and password = '${criteria.password}'` : true;
    criteria.user_type ? conditions += ` and user_type = '${criteria.user_type}'` : true;
    criteria.status ? conditions += ` and status = '1'` : true;

    dbConfig.getDB().query(`select u.*,ui.* from s_users as u left join  s_vendors as ui on u.user_id = ui.user_id where  ${conditions}`, callback);

}

/**** Update Device Token *****/

let updateDeviceToken = (criteria, dataToSet, callback) => {

    //update keys 
    let setData = "";
    if (dataToSet.device_token)
        dataToSet.device_token ? setData += `device_token = '${dataToSet.device_token}',` : true;
    dataToSet.device_type ? setData += `device_type = '${dataToSet.device_type}'` : true;

    let conditions = "";
    criteria.user_id ? conditions += `user_id ='${criteria.user_id}'` : true;
    dbConfig.getDB().query(`UPDATE s_users SET ${setData} where ${conditions} `, callback);
}

/**** Update Profile *****/
let updateProfile = (dataToSet, callback) => {
    //update keys 
    dbConfig.getDB().query("insert into s_temp_profile set ? ", dataToSet, callback);
}

/**** Update Store Timings *****/

let updateStoreTimings = (criteria, dataToSet, callback) => {

    //update keys 
    let setData = "";
    dataToSet.open_time ? setData += `open_time = '${dataToSet.open_time}',` : true;
    dataToSet.close_time ? setData += `close_time = '${dataToSet.close_time}',` : true;
    dataToSet.status ? setData += `status = '${dataToSet.status}'` : true;

    let conditions = "";
    criteria.user_id ? conditions += `user_id ='${criteria.user_id}'` : true;
    criteria.day ? conditions += ` AND day ='${criteria.day}'` : true;
    dbConfig.getDB().query(`UPDATE s_vendor_timings SET ${setData} where ${conditions} `, callback);
}

/**** Add delivery charges *****/

let addDeliveryCharge = (criteria, dataToSet, callback) => {

    //update keys 
    let setData = "";
    dataToSet.base_delivery_charge ? setData += `base_delivery_charge = '${dataToSet.base_delivery_charge}',` : true;
    dataToSet.delivery_charge_per_km ? setData += `delivery_charge_per_km = '${dataToSet.delivery_charge_per_km}'` : true;

    let conditions = "";
    criteria.user_id ? conditions += `user_id ='${criteria.user_id}'` : true;
    dbConfig.getDB().query(`UPDATE s_vendors SET ${setData} where ${conditions} `, callback);
}

/**** Create delivery executive *****/
let addDeliveryExecutive = (dataToSet, callback) => {
    dbConfig.getDB().query("insert into s_delivery_boy set ? ", dataToSet, callback);
}

/**** Get delivery executive list *****/
let getVendorList = (criteria, callback) => {
    let conditions = "";
    criteria.user_id ? conditions += `u.vendor_id = '${criteria.user_id}'` : true;
    dbConfig.getDB().query(`select u.* from s_delivery_boy as u where ${conditions}`, callback);
}

/**** Get delivery data *****/
let getDeliveryData = (criteria, callback) => {
    let conditions = "";
    criteria.user_id ? conditions += `u.user_id = '${criteria.user_id}'` : true;
    dbConfig.getDB().query(`select u.base_delivery_charge,delivery_charge_per_km from s_vendors as u where ${conditions}`, callback);
}

/**** Create Inventory *****/
let addInventory = (dataToSet, callback) => {
    dbConfig.getDB().query("insert into s_inventory set ? ", dataToSet, function(err, result) {
        if (err) throw err;

        callback(null, result.insertId);

    });
}

/**** Create Inventory variants *****/
let createVariants = (dataToSet, callback) => {
    let conditions = "";
    dataToSet.item_id ? conditions += `item_id = '${dataToSet.item_id}'` : true;
    //  dbConfig.getDB().query(`DELETE from s_inventory_variants where ${conditions}`, null);

    dbConfig.getDB().query("insert into s_inventory_variants set ? ", dataToSet, callback);
}

/**** Get business category list *****/
let getBusinessCategory = (callback) => {

    dbConfig.getDB().query(`select u.* from s_business_category as u `, callback);
}

/**** Get category list *****/
let getCategory = (criteria, callback) => {

    dbConfig.getDB().query(`select u.* from s_categories as u `, callback);
}

/**** Get products list *****/
let getProducts = (criteria, callback) => {
    let conditions = "";
    criteria.user_id ? conditions += `u.vendor_id = '${criteria.user_id}'` : true;
    dbConfig.getDB().query(`select u.* from s_inventory as u where ${conditions}`, callback);
}

/**** Get products data *****/
let getProductDetails = (criteria, callback) => {
    let conditions = "";
    criteria.product_id ? conditions += `u.id = '${criteria.product_id}'` : true;
    dbConfig.getDB().query(`select u.*,c.name as category_name from s_inventory as u left join s_categories as c on u.category_id = c.id where ${conditions}`, function(err, res) {
        if (err) {
            callback(err, null)
        } else {
            var inventory_id = criteria.product_id;
            dbConfig.getDB().query(`SELECT v.unit_type,v.unit_qty,ROUND(v.unit_price,2) as price FROM s_inventory as p JOIN s_inventory_variants as v ON p.id = v.item_id  WHERE p.id = ${inventory_id} AND p.status = "1" `, function(err, res1) {
                console.log(res1)
                res['0'].variants = res1 ? res1 : '';
                callback(null, res);
            });

        }
    });
}

/**** Update Inventory *****/

let updateInventory = (criteria, dataToSet, callback) => {
    //update keys 

    let setData = "";
    dataToSet.service_type ? setData += `service_type = '${dataToSet.service_type}',` : true;
    dataToSet.item_image ? setData += `item_image = '${dataToSet.item_image}',` : true;
    dataToSet.category_id ? setData += `category_id = '${dataToSet.category_id}',` : true;
    dataToSet.name ? setData += `name = '${dataToSet.name}',` : true;
    dataToSet.description != '' ? setData += `description = '${dataToSet.description}',` : setData += `description = '',`;
    dataToSet.in_stock ? setData += `in_stock = '${dataToSet.in_stock}',` : true;
    dataToSet.eta ? setData += `eta = '${dataToSet.eta}',` : true;
    dataToSet.subscription_type ? setData += `subscription_type = '${dataToSet.subscription_type}',` : true;
    dataToSet.base_price ? setData += `base_price = '${dataToSet.base_price}'` : true;


    let conditions = "";
    criteria.item_id ? conditions += `id ='${criteria.item_id}'` : true;
    let conditions1 = "";
    criteria.item_id ? conditions1 += `item_id ='${criteria.item_id}'` : true;
    dbConfig.getDB().query(`DELETE from s_inventory_variants where ${conditions1}`, null);
    dbConfig.getDB().query(`UPDATE s_inventory SET ${setData} where ${conditions} `, callback);

}

let get_orders = (criteria, callback) => {
        if (criteria.order_status == 'active') {
            dbConfig.getDB().query(`SELECT o.id,o.order_unique_id,o.order_type,o.currency,o.order_price,o.order_status,payment_mode,o.added_on as order_date ,(SELECT COUNT(id) FROM s_order_details as od where od.order_id = o.id) as total_items FROM s_orders as o WHERE o.vendor_id = ${criteria.user_id} and o.order_status IN('Pending','Confirmed','On the way','Picked up') ORDER BY o.id DESC
        `, callback)
        } else {
            dbConfig.getDB().query(`SELECT o.id,o.order_unique_id,o.order_type,o.currency,o.order_price,o.order_status,payment_mode,o.added_on as order_date ,(SELECT COUNT(id) FROM s_order_details as od where od.order_id = o.id) as total_items FROM s_orders as o WHERE o.vendor_id =  ${criteria.user_id} and o.order_status IN('Delivered','Cancel') ORDER BY o.id DESC`, callback)

        }

    }
    /**  order data */

let get_order_details = (criteria, callback) => {
    dbConfig.getDB().query(`SELECT o.id as order_id,o.order_unique_id,v.delivery_mode,o.user_id,o.address,o.lat,o.lng,o.order_status,o.payment_mode,o.order_type,i.id as item_id,od.quantity,i.name as item_name,i.description,i.item_image,od.currency,od.price as price,o.added_on as date FROM s_orders as o LEFT join s_order_details as od on o.id = od.order_id left join s_inventory as i on i.id = od.item_id left join s_vendors as v on v.user_id = o.vendor_id WHERE o.id = ${criteria.order_id}`, callback)

}

/**** Update Delivery Mode *****/
let updateDeliveryMode = (dataToSet, callback) => {
    //update keys 
    dbConfig.getDB().query("insert into s_temp_profile set ? ", dataToSet, callback);
}

/****Change Order Status *****/
let changeOrderStatus = (dataToSet, criteria, callback) => {
    //update keys 
    let setData = "";
    dataToSet.order_status ? setData += `order_status = '${dataToSet.order_status}'` : true;
    let conditions = "";
    criteria.order_id ? conditions += `id ='${criteria.order_id}'` : true;

    dbConfig.getDB().query(`UPDATE s_orders SET ${setData} where ${conditions} `, callback);
}

/****Update Password *****/
let updatePassword = (dataToSet, criteria, callback) => {
    //update keys 
    let setData = "";
    dataToSet.password ? setData += `password = '${dataToSet.password}'` : true;
    let conditions = "";
    criteria.mobile_no ? conditions += `mobile_no ='${criteria.mobile_no}'` : true;
    criteria.user_type ? conditions += `and user_type = '${criteria.user_type}'` : true;

    dbConfig.getDB().query(`UPDATE s_users SET ${setData} where ${conditions} `, callback);
}

module.exports = {
    createUser: createUser,
    createUserInfo: createUserInfo,
    createUserTimings: createUserTimings,
    getUsers: getUsers,
    getUserData: getUserData,
    getUsersLogin: getUsersLogin,
    updateDeviceToken: updateDeviceToken,
    updateProfile: updateProfile,
    updateStoreTimings: updateStoreTimings,
    addDeliveryCharge: addDeliveryCharge,
    addDeliveryExecutive: addDeliveryExecutive,
    getVendorList: getVendorList,
    getDeliveryData: getDeliveryData,
    addInventory: addInventory,
    createVariants: createVariants,
    getBusinessCategory: getBusinessCategory,
    getCategory: getCategory,
    getProducts: getProducts,
    getProductDetails: getProductDetails,
    updateInventory: updateInventory,
    get_orders: get_orders,
    get_order_details: get_order_details,
    updateDeliveryMode: updateDeliveryMode,
    changeOrderStatus: changeOrderStatus,
    updatePassword: updatePassword

}