/*
 * @Author: Hitesh
 * @Date: May 3, 2021
 */


'use strict';

let dbConfig = require("../Utilities/dbConfig");
let qb = require("../Utilities/dbConfig").qb;

/**** Get Admin Login Data *****/
let getAdminLogin = (criteria, callback) => {
    let conditions = "";

    criteria.email_id ? conditions += `email_id = '${criteria.email_id}'` : true;
    criteria.password ? conditions += ` and password = '${criteria.password}'` : true;
    criteria.user_type ? conditions += `user_type = 'admin'` : true;

    dbConfig.getDB().query(`select * from s_users where  ${conditions}`, callback);

}

/**** Update Vendor *****/
let updateVendor = (criteria, dataToSet, callback) => {
    let setData = "";
    dataToSet.status ? setData += `status = '${dataToSet.status}'` : true;

    let conditions = "";
    criteria.id ? conditions += `id ='${criteria.id}'` : true;

    dbConfig.getDB().query(`UPDATE s_business_category SET ${setData} where ${conditions} `, callback);
}

/**** Add Vendor Category *****/
let addVendorCategory = (dataToSet, callback) => {
    dbConfig.getDB().query("insert into s_business_category set ? ", dataToSet, callback);
}

/**** Get Vendor category list *****/
let getVendorCategory = (criteria, callback) => {
    dbConfig.getDB().query(`select * from s_business_category`, callback);
}

/**** Edit Vendor Category *****/
let editVendorCategory = (criteria, dataToSet, callback) => {

    let conditions = "";
    criteria.id ? conditions += `id ='${criteria.id}'` : true;

    let setData = "";
    dataToSet.category_name ? setData += `category_name = '${dataToSet.category_name}'` : true;
    dataToSet.image ? setData += `,image = '${dataToSet.image}'` : true

    dbConfig.getDB().query(`UPDATE s_business_category SET ${setData} where ${conditions} `, callback);
}

/**** Update Product *****/
let updateProduct = (criteria, dataToSet, callback) => {
    let setData = "";
    dataToSet.status ? setData += `status = '${dataToSet.status}'` : true;

    let conditions = "";
    criteria.id ? conditions += `id ='${criteria.id}'` : true;

    dbConfig.getDB().query(`UPDATE s_categories SET ${setData} where ${conditions} `, callback);
}

/**** Add Product Category *****/
let addProductCategory = (dataToSet, callback) => {
    dbConfig.getDB().query("insert into s_categories set ? ", dataToSet, callback);
}

/**** Get Product category list *****/
let getProductCategory = (criteria, callback) => {
    dbConfig.getDB().query(`select * from s_categories`, callback);
}

/**** Edit Product Category *****/
let editProductCategory = (criteria, dataToSet, callback) => {
    let conditions = "";
    criteria.id ? conditions += `id ='${criteria.id}'` : true;

    let setData = "";
    dataToSet.name ? setData += `name = '${dataToSet.name}'` : true;
    dataToSet.description ? setData += `,description = '${dataToSet.description}'` : true;
    dataToSet.category_image ? setData += `,category_image = '${dataToSet.category_image}'` : true

    dbConfig.getDB().query(`UPDATE s_categories SET ${setData} where ${conditions} `, callback);
}

/**** Get Active Stores Data *****/
let getActiveStores = (criteria, callback) => {
    let conditions = "";
    criteria.status ? conditions += `u.status ='1'` : true;
    dbConfig.getDB().query(`select u.vendor_id, u.store_name, u.registration_number, u.store_address, ui.category_name, uj.mobile_no from s_business_category as ui left join s_vendors as u on u.category_id = ui.id left join s_users as uj on u.user_id = uj.user_id where ${conditions}`, callback);
}

/**** Export Active Stores Listing  *****/
let exportActiveStores = (criteria, callback) => {
    dbConfig.getDB().query(`select u.vendor_id, u.store_name, u.registration_number, u.store_address, ui.category_name, uj.mobile_no from s_business_category as ui left join s_vendors as u on u.category_id = ui.id left join s_users as uj on u.user_id = uj.user_id where u.status = '1'`, callback);
}

/**** Get New Stores Data *****/
let getNewStores = (criteria, callback) => {
    dbConfig.getDB().query(`select u.vendor_id, u.store_name, u.registration_number, u.store_address, ui.category_name, uj.mobile_no from s_business_category as ui left join s_vendors as u on u.category_id = ui.id left join s_users as uj on u.user_id = uj.user_id where u.status = '0'`, callback);
}

/**** Export New Stores Listing  *****/
let exportNewStores = (criteria, callback) => {
    dbConfig.getDB().query(`select u.vendor_id, u.store_name, u.registration_number, u.store_address, ui.category_name, uj.mobile_no from s_business_category as ui left join s_vendors as u on u.category_id = ui.id left join s_users as uj on u.user_id = uj.user_id where u.status = '0'`, callback);
}

/**** Approve New Store *****/
let approveStore = (criteria, /*dataToSet,*/ callback) => {
    // let setData = "";
    // dataToSet.status ? setData += `status = '${dataToSet.status}'` : true;

    let conditions = "";
    criteria.user_id ? conditions += `user_id ='${criteria.user_id}'` : true;
    criteria.user_type ? conditions += `user_type ='vendor'` : true;

    dbConfig.getDB().query(`UPDATE s_users SET status = '1' where ${conditions} `, callback);
}

/**** Get Update Request Data *****/
let getUpdateRequest = (criteria, callback) => {
    dbConfig.getDB().query(`select * from s_temp_profile`, callback);    
}

/**** Export Update Request Listing  *****/
let exportUpdateRequest = (criteria, callback) => {
    dbConfig.getDB().query(`select * from s_temp_profile`, callback);
}

/**** Get Update Request Data *****/
let getUpdateReq = (criteria, callback) => {
    let conditions = "";
    criteria.user_id ? conditions += `user_id ='${criteria.user_id}'` : true;
    dbConfig.getDB().query(`select * from s_temp_profile where ${conditions}`, callback);    
}

/**** Approve Update Request *****/
let approveUpdateRequest= (criteria, dataToSet, callback) => {
    let setData = "";
    dataToSet.store_name ? setData += `v.store_name = '${dataToSet.store_name}'` : true;
    dataToSet.email_id ? setData += `, u.email_id = '${dataToSet.email_id}'` : true;
    dataToSet.country_code ? setData += `, u.country_code = '${dataToSet.country_code}'` : true;
    dataToSet.mobile_no ? setData += `, u.mobile_no = '${dataToSet.mobile_no}'` : true;
    dataToSet.store_address ? setData += `, v.store_address = '${dataToSet.store_address}'` : true;
    dataToSet.minimun_order ? setData += `, v.minimun_order = '${dataToSet.minimun_order}'` : true;
    dataToSet.twitter_profile ? setData += `, v.twitter_profile = '${dataToSet.twitter_profile}'` : true;
    dataToSet.instagram_profile ? setData += `, v.instagram_profile = '${dataToSet.instagram_profile}'` : true;    
    dataToSet.facebook_profile ? setData += `, v.facebook_profile = '${dataToSet.facebook_profile}'` : true;
    dataToSet.profile_pic ? setData += `, u.profile_pic = '${dataToSet.profile_pic}'` : true;
    dataToSet.registration_number ? setData += `, v.registration_number = '${dataToSet.registration_number}'` : true;
    dataToSet.gstin_number ? setData += `, v.gstin_number = '${dataToSet.gstin_number}'` : true;
    dataToSet.store_type ? setData += `, v.store_type = '${dataToSet.store_type}'` : true;
    dataToSet.currency ? setData += `, v.currency = '${dataToSet.currency}'` : true;
    dataToSet.delivery_mode ? setData += `, v.delivery_mode = '${dataToSet.delivery_mode}'` : true;

    let conditions = "";
    criteria.user_id ? conditions += `u.user_id ='${criteria.user_id}'` : true;
    criteria.user_type ? conditions += `u.user_type ='vendor'` : true;

    dbConfig.getDB().query(`UPDATE s_users as u left join s_vendors as v on u.user_id=v.user_id SET ${setData} where ${conditions} `, callback);
}


/**** Get Store Details of Active Stores *****/
let activeStoreDetails = (criteria, callback) => {
    let conditions = "";
    criteria.vendor_id ? conditions += `u.vendor_id ='${criteria.vendor_id}'` : true;
    criteria.status ? conditions += `u.status ='1'` : true;

    dbConfig.getDB().query(`select u.*,ui.* from s_vendors as u left join s_vendor_timings as ui on u.user_id = ui.user_id where ${conditions} `, callback);
}

/**** Get Documents of Active Stores *****/
let activeStoreDocuments = (criteria, callback) => {
    let conditions = "";
    criteria.vendor_id ? conditions += `vendor_id ='${criteria.vendor_id}'` : true;
    criteria.status ? conditions += `status ='1'` : true;

    dbConfig.getDB().query(`select pan_card, gst from s_vendors where ${conditions}`, callback);
}

/**** Get Inventory of Active Stores *****/
let activeStoreInventory = (criteria, callback) => {
    let conditions = "";
    criteria.vendor_id ? conditions += `u.vendor_id ='${criteria.vendor_id}'` : true;
    criteria.status ? conditions += `u.status ='1'` : true;

    dbConfig.getDB().query(`select u.*,ui.* from s_inventory as u left join s_inventory_variants as ui on u.id = ui.item_id where ${conditions}`, callback);
}

/**** Get Orders of Active Stores *****/
let activeStoreOrders = (criteria, callback) => {
    let conditions = "";
    criteria.vendor_id ? conditions += `ui.vendor_id = '${criteria.vendor_id}'` : true;
    dbConfig.getDB().query(`select ui.order_unique_id, u.user_id, u.first_name, u.last_name, u.mobile_no, ui.address, ui.order_price, ui.order_type, ui.added_on, ui.order_status from s_users as u left join s_orders as ui on u.user_id = ui.user_id where ${conditions}`, callback);
}
// u.*,ui.* from s_orders as u left join s_vendors as ui on u.vendor_id = ui.user_id

/**** Get Customers Listing *****/
let getCustomers = (criteria, callback) => {
    dbConfig.getDB().query(`select user_id, first_name, last_name, email_id, mobile_no, gender, date_of_birth, referal_code, wallet from s_users where user_type = 'customer' and status = '1'`, callback);
}

/**** Export Customer Listing  *****/
let exportCustomers = (criteria, callback) => {
    dbConfig.getDB().query(`select * from s_users where user_type = 'customer'`, callback);
}
// into outfile "F:\\ServiceKart\\userData.csv" fields terminated by ',' lines terminated by '\n'

/**** Get Personal Details of Customers *****/
let getCustomerDetails = (criteria, callback) => {
    let conditions = "";
    criteria.user_id ? conditions += `u.user_id = '${criteria.user_id}'` : true;
    dbConfig.getDB().query(`select u.user_id, u.first_name, u.last_name, u.email_id, u.mobile_no, u.gender, u.date_of_birth, u.referal_code, ui.city from s_users as u left join s_user_address as ui on u.user_id = ui.user_id where ${conditions}`, callback);
}

/**** Get Orders of Customers *****/
let getCustomerOrders = (criteria, callback) => {
    let conditions = "";
    criteria.user_id ? conditions += `u.user_id = '${criteria.user_id}'` : true;
    dbConfig.getDB().query(`select ui.order_unique_id, u.user_id, u.first_name, u.last_name, u.mobile_no, ui.address, ui.order_price, ui.order_type, ui.added_on, ui.order_status from s_users as u left join s_orders as ui on u.user_id = ui.user_id where ${conditions}`, callback);
}

/**** Get Active Orders List *****/
let getActiveOrders = (criteria, callback) => {
    dbConfig.getDB().query(`select ui.order_unique_id, u.first_name, u.last_name, u.mobile_no, ui.address, ui.order_price, uj.store_name, ui.added_on, ui.order_status from s_users as u left join s_orders as ui on u.user_id = ui.user_id left join s_vendors as uj on ui.vendor_id = uj.user_id where order_status = 'pending' or order_status = 'received' or order_status = 'confirmed'`, callback);
}

/**** Export Active Orders List to Excel *****/
let exportActiveOrders = (criteria, callback) => {
    dbConfig.getDB().query(`select ui.order_unique_id, u.first_name, u.last_name, u.mobile_no, ui.address, ui.order_price, uj.store_name, ui.added_on, ui.order_status from s_users as u left join s_orders as ui on u.user_id = ui.user_id left join s_vendors as uj on ui.vendor_id = uj.user_id where order_status = 'pending' or order_status = 'received' or order_status = 'confirmed`, callback);
}

/**** Get Delivered Orders List *****/
let getDeliveredOrders = (criteria, callback) => {
    dbConfig.getDB().query(`select ui.order_unique_id, u.first_name, u.last_name, u.mobile_no, ui.address, ui.order_price, uj.store_name, ui.added_on, ui.order_status from s_users as u left join s_orders as ui on u.user_id = ui.user_id left join s_vendors as uj on ui.vendor_id = uj.user_id where order_status = 'delivered'`, callback);
}

/**** Export Delivered Orders List to Excel *****/
let exportDeliveredOrders = (criteria, callback) => {
    dbConfig.getDB().query(`select ui.order_unique_id, u.first_name, u.last_name, u.mobile_no, ui.address, ui.order_price, uj.store_name, ui.added_on, ui.order_status from s_users as u left join s_orders as ui on u.user_id = ui.user_id left join s_vendors as uj on ui.vendor_id = uj.user_id where order_status = 'delivered'`, callback);
}

/**** Get Cancelled Orders List *****/
let getCancelledOrders = (criteria, callback) => {
    dbConfig.getDB().query(`select ui.order_unique_id, u.first_name, u.last_name, u.mobile_no, ui.address, ui.order_price, uj.store_name, ui.added_on, ui.order_status from s_users as u left join s_orders as ui on u.user_id = ui.user_id left join s_vendors as uj on ui.vendor_id = uj.user_id where order_status = 'cancelled'`, callback);
}

/**** Export Cancelled Orders List to Excel *****/
let exportCancelledOrders = (criteria, callback) => {
    dbConfig.getDB().query(`select ui.order_unique_id, u.first_name, u.last_name, u.mobile_no, ui.address, ui.order_price, uj.store_name, ui.added_on, ui.order_status from s_users as u left join s_orders as ui on u.user_id = ui.user_id left join s_vendors as uj on ui.vendor_id = uj.user_id where order_status = 'cancelled'`, callback);
}

/**** Get Details of Active Orders *****/
let activeOrderDetails = (criteria, callback) => {
    dbConfig.getDB().query(`select o.id, o.order_unique_id, o.added_on, o.user_id, o.vendor_id, o.address, o.payment_mode, o.order_type, o.currency, o.order_price, od.quantity, od.currency, od.price, i.name from s_orders as o left join s_order_details as od on o.id = od.order_id left join s_inventory as i on od.item_id = i.id where o.id = ${criteria.order_id}`, callback);
}

/**** Get Users *****/
let getUsers = (criteria, callback) => {
    let conditions = "";
    if (criteria.email_id) {
        criteria.email_id ? conditions += `u.email_id = '${criteria.email_id}'` : true;
    }
    if (criteria.mobile_no) {
        criteria.mobile_no ? conditions += `u.mobile_no = '${criteria.mobile_no}'` : true;
    }
    if (criteria.user_id) {
        criteria.user_id ? conditions += `u.user_id = '${criteria.user_id}'` : true;
    }

    criteria.user_type ? conditions += `and u.user_type = '${criteria.user_type}'` : true;
    conditions += ` and status = '1'`;
    dbConfig.getDB().query(`select u.*,IF((SELECT COUNT(address_id) from s_user_address where user_id = u.user_id )>0,'1','0')as is_address from s_users as u where ${conditions}`, callback);
}

/**** Get Store Details *****/
let getStoreDetails = (criteria, callback) => {
    let conditions = "";
    conditions += `v.user_id ='${criteria.vendor_id}'`;

    dbConfig.getDB().query(`select v.*, u.* from s_vendors as v left join s_users as u on v.user_id = u.user_id where ${conditions} `, callback);
}

/**** Add Promotion Banner *****/
let addBanner = (dataToSet, callback) => {
    dbConfig.getDB().query("insert into s_promotions set ? ", dataToSet, callback);
}

/**** Get Promotions List *****/
let getPromotions = (criteria, callback) => {
    dbConfig.getDB().query(`select p.id, p.banner_image, p.start_date, p.end_date, p.banner_title, p.latitude, p.longitude, p.banner_path from s_promotions as p where status = '1'`, callback);
}

/**** Delete Promotion Banner *****/
let deleteBanner = (criteria, callback) => {
    let conditions = "";
    criteria.id ? conditions += `id = '${criteria.id}'` : true;
    dbConfig.getDB().query(`UPDATE s_promotions SET status = '0' where ${conditions}`, callback);
}

/**** Edit Promotion Banner *****/
let editBanner = (criteria, dataToSet, callback) => {

    let conditions = "";
    criteria.id ? conditions += `id ='${criteria.id}'` : true;

    let setData = "";
    dataToSet.banner_title ? setData += `banner_title = '${dataToSet.banner_title}'` : true;
    dataToSet.description ? setData += `,description = '${dataToSet.description}'` : true
    dataToSet.start_date ? setData += `,start_date = '${dataToSet.start_date}'` : true
    dataToSet.end_date ? setData += `,end_date = '${dataToSet.end_date}'` : true
    dataToSet.banner_path ? setData += `,banner_path = '${dataToSet.banner_path}'` : true
    dataToSet.distance ? setData += `,distance = '${dataToSet.distance}'` : true
    dataToSet.banner_priority ? setData += `,banner_priority = '${dataToSet.banner_priority}'` : true
    dataToSet.banner_image ? setData += `,banner_image = '${dataToSet.banner_image}'` : true
    dataToSet.discount_type ? setData += `,discount_type = '${dataToSet.discount_type}'` : true
    dataToSet.discount_value ? setData += `,discount_value = '${dataToSet.discount_value}'` : true
    dataToSet.min_order_value ? setData += `,min_order_value = '${dataToSet.min_order_value}'` : true

    dbConfig.getDB().query(`UPDATE s_promotions SET ${setData} where ${conditions} `, callback);
}

/**** Add Delivery Boy *****/
let addDeliveryBoy = (dataToSet, callback) => {
    dbConfig.getDB().query("insert into s_users set ? ", dataToSet, callback);
}

/**** Add Delivery Boy Documents *****/
let addDeliveryBoyDocs = (dataToSet, callback) => {
    dbConfig.getDB().query("insert into s_user_documents set ? ", dataToSet, callback);
}

/**** Get Delivery Boys List *****/
let getDrivers = (criteria, callback) => {
    if (criteria.status == 'active') {
        dbConfig.getDB().query(`select u.user_id, u.first_name, u.last_name, u.mobile_no, u.added_on, u.status from s_users as u where u.user_type = 'driver' and u.status = '1' ORDER BY u.user_id DESC`, callback);
    } else {
        dbConfig.getDB().query(`select u.user_id, u.first_name, u.last_name, u.mobile_no, u.added_on, u.status from s_users as u where u.user_type = 'driver' and u.status = '0' ORDER BY u.user_id DESC`, callback);

    }
}

/**** Export Active Drivers List to Excel *****/
let exportActiveDrivers = (criteria, callback) => {
    dbConfig.getDB().query(`select u.user_id, u.first_name, u.last_name, u.mobile_no, u.added_on, u.status from s_users as u where u.user_type = 'driver' and u.status = '1' ORDER BY u.user_id DESC`, callback);
}

/**** Export New Drivers List to Excel *****/
let exportNewDrivers = (criteria, callback) => {
    dbConfig.getDB().query(`select u.user_id, u.first_name, u.last_name, u.mobile_no, u.added_on, u.status from s_users as u where u.user_type = 'driver' and u.status = '0' ORDER BY u.user_id DESC`, callback);
}

/**** Approve New Driver *****/
let approveNewDriver = (criteria, /*dataToSet,*/ callback) => {
    // let setData = "";
    // dataToSet.status ? setData += `status = '${dataToSet.status}'` : true;

    let conditions = "";
    criteria.user_id ? conditions += `user_id ='${criteria.user_id}'` : true;
    criteria.user_type ? conditions += `user_type ='driver'` : true;
    criteria.status ? conditions += `status ='0'` : true;

    dbConfig.getDB().query(`UPDATE s_users SET status = '1' where ${conditions} `, callback);
}

/**** Search *****/
// let search = (criteria, callback) => {
//     // let conditions = "";
//     // criteria.email_id ? conditions += `email_id = '${criteria.email_id}'` : true;
//     // criteria.first_name ? conditions += `first_name = '${criteria.first_name}'` : true;
//     // criteria.last_name != "? conditions +" last_name like ${criteria.last_name} : true;
//     // criteria.user_type ? conditions += `user_type = 'customer'` : true;
    
//     dbConfig.getDB().query(`SELECT * FROM s_users WHERE last_name LIKE ? %Gupta% `, callback);
// }

module.exports = {
    getAdminLogin: getAdminLogin,
    updateVendor: updateVendor,
    addVendorCategory: addVendorCategory,
    getVendorCategory: getVendorCategory,
    editVendorCategory: editVendorCategory,
    updateProduct: updateProduct,
    addProductCategory: addProductCategory,
    getProductCategory: getProductCategory,
    editProductCategory: editProductCategory,
    getActiveStores: getActiveStores,
    exportActiveStores: exportActiveStores,
    getNewStores: getNewStores,
    exportNewStores: exportNewStores,
    approveStore: approveStore,
    getUpdateRequest: getUpdateRequest,
    exportUpdateRequest: exportUpdateRequest,
    getUpdateReq: getUpdateReq,
    approveUpdateRequest: approveUpdateRequest,
    activeStoreDetails: activeStoreDetails,
    activeStoreDocuments: activeStoreDocuments,
    activeStoreInventory: activeStoreInventory,
    activeStoreOrders: activeStoreOrders,
    getCustomers: getCustomers,
    exportCustomers: exportCustomers,
    getCustomerDetails: getCustomerDetails,
    getCustomerOrders: getCustomerOrders,
    getActiveOrders: getActiveOrders,
    exportActiveOrders: exportActiveOrders,
    getDeliveredOrders: getDeliveredOrders,
    exportDeliveredOrders: exportDeliveredOrders,
    getCancelledOrders: getCancelledOrders,
    exportCancelledOrders: exportCancelledOrders,
    activeOrderDetails: activeOrderDetails,
    getUsers: getUsers,
    getStoreDetails: getStoreDetails,
    addBanner: addBanner,
    getPromotions: getPromotions,
    deleteBanner: deleteBanner,
    editBanner: editBanner,
    addDeliveryBoy: addDeliveryBoy,
    addDeliveryBoyDocs: addDeliveryBoyDocs,
    getDrivers: getDrivers,
    exportActiveDrivers: exportActiveDrivers,
    exportNewDrivers: exportNewDrivers,
    approveNewDriver: approveNewDriver,
    // search: search
}