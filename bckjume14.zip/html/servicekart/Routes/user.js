/*
 * @Author: Tripti Bhardwaj
 * @Date: April 5, 2021
 */

let express = require('express'),
    router = express.Router(),
    aws = require('aws-sdk'),
    multer = require('multer'),
    multerS3 = require('multer-s3-transform'),
    fs = require('fs'),
    sharp = require('sharp'),
    util = require('../Utilities/util'),
    vendorService = require('../Services/vendor');
authHandler = require('../middleware/verifyToken');

aws.config.update({
    secretAccessKey: 'BnR6ekIgeoIs+sEiymbQ/v0tAsZoxyJ8i917Wd5a',
    accessKeyId: 'AKIAQZB4HPZ4MBDHBAOJ',
    region: 'ap-south-1'
});

const s3 = new aws.S3();


var upload = multer({
    storage: multerS3({
        s3: s3,
        bucket: 'servicekaart',
        acl: 'public-read',
        shouldTransform: function(req, file, cb) {
            cb(null, /^image/i.test(file.mimetype))
        },
        transforms: [{
            id: 'original',
            key: function(req, file, cb) {
                cb(null, Date.now().toString() + 'original' + ".jpg")
            },
            transform: function(req, file, cb) {
                cb(null, sharp())
            }
        }, {
            id: 'thumbnail',
            key: function(req, file, cb) {
                cb(null, Date.now().toString() + 'thumbnail' + ".jpg")
            },
            transform: function(req, file, cb) {
                cb(null, sharp().resize(50, 50))
            }
        }]
    })
})

let cpUpload = upload.fields([{ name: 'profile', maxCount: 1 }, { name: 'pan', maxCount: 1 }, { name: 'gst', maxCount: 1 }, ]);
let cpUpload1 = upload.fields([{ name: 'profile', maxCount: 1 }]);


/* check Mobile */
router.post('/checkMobile', (req, res) => {
    vendorService.checkMobile(req.body, (data) => {
        res.send(data);
    });
});

/* check Email */
router.post('/checkEmail', (req, res) => {
    vendorService.checkEmail(req.body, (data) => {
        res.send(data);
    });
});

/* vendor signup */
router.post('/vendorSignUp', cpUpload, (req, res) => {
    vendorService.signup(req.body, req.files, (data) => {
        res.send(data);
    });
});

/* vendor login */
router.post('/vendorLogin', (req, res) => {
    vendorService.login(req.body, (data) => {
        res.send(data);
    });
});

/* vendor account details */
router.get('/getDetails', authHandler.verifyToken, (req, res) => {
    vendorService.getDetails(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/* update device token */
router.post('/updateDeviceToken', authHandler.verifyToken, (req, res) => {
    vendorService.updateDeviceToken(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/* update profile */
router.post('/updateProfile', authHandler.verifyToken, (req, res) => {
    vendorService.updateProfile(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/* update store timings */
router.post('/updateStoreTimings', authHandler.verifyToken, (req, res) => {
    vendorService.updateStoreTimings(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/* add delivery charge */
router.post('/addDeliveryCharge', authHandler.verifyToken, (req, res) => {
    vendorService.addDeliveryCharge(req.body, req.headers, (data) => {
        res.send(data);
    });

});
/* add delivery executive */
router.post('/addDeliveryExecutive', authHandler.verifyToken, (req, res) => {
    vendorService.addDeliveryExecutive(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/* vendor list details */
router.get('/getDeliveryDetails', authHandler.verifyToken, (req, res) => {
    vendorService.getDeliveryDetails(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/* add inventory */
router.post('/addInventory', authHandler.verifyToken, (req, res) => {
    vendorService.addInventory(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/* business category list */
router.get('/getBusinessCategory', (req, res) => {
    vendorService.getBusinessCategory(req.body, (data) => {
        res.send(data);
    });

});

/*  category list */
router.get('/getCategory', authHandler.verifyToken, (req, res) => {
    vendorService.getCategory(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/*  product list */
router.get('/getProducts', authHandler.verifyToken, (req, res) => {
    vendorService.getProducts(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/* get product details */
router.post('/getProductDetails', authHandler.verifyToken, (req, res) => {
    vendorService.getProductDetails(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/* update Inventory*/
router.post('/updateInventory', authHandler.verifyToken, (req, res) => {
    vendorService.updateInventory(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/* Orders List*/
router.post('/getOrders', authHandler.verifyToken, (req, res) => {
    vendorService.get_orders(req.body, req.headers, (data) => {
        res.send(data);
    });

});
/*Order Details*/
router.post('/getOrderDetail', authHandler.verifyToken, (req, res) => {
    vendorService.get_order_detail(req.body, req.headers, (data) => {
        res.send(data);
    });

});


/* update delivery mode */
router.post('/updateDeliveryMode', authHandler.verifyToken, (req, res) => {
    vendorService.updateDeliveryMode(req.body, req.headers, (data) => {
        res.send(data);
    });

});


/* change order status */
router.post('/changeOrderStatus', authHandler.verifyToken, (req, res) => {
    vendorService.changeOrderStatus(req.body, req.headers, (data) => {
        res.send(data);
    });

});

/* change password */
router.post('/resetPassword', (req, res) => {
    vendorService.resetPassword(req.body, (data) => {
        res.send(data);
    });

});

module.exports = router;