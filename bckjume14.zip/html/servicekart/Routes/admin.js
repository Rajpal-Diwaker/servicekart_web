/*
 * @Author: Hitesh
 * @Date: May 3, 2021
 */

let express = require('express'),
    router = express.Router(),
    util = require('../Utilities/util'),
    adminService = require('../Services/adminService');
authHandler = require('../middleware/verifyToken');

    aws = require('aws-sdk'),
    multer = require('multer'),
    multerS3 = require('multer-s3-transform'),
    fs = require('fs'),
    sharp = require('sharp'),


aws.config.update({
    secretAccessKey: 'BnR6ekIgeoIs+sEiymbQ/v0tAsZoxyJ8i917Wd5a',
    accessKeyId: 'AKIAQZB4HPZ4MBDHBAOJ',
    region: 'ap-south-1'
});

const s3 = new aws.S3();

// var upload = multer({
//     storage: multerS3({
//         s3: s3,
//         bucket: 'servicekaart',
//         acl: 'public-read',
//         shouldTransform: function(req, file, cb) {
//             cb(null, /^image/i.test(file.mimetype))
//         },
//         transforms: [{
//             id: 'original',
//             key: function(req, file, cb) {
//                 cb(null, Date.now().toString() + 'original' + ".jpg")
//             },
//             transform: function(req, file, cb) {
//                 cb(null, sharp())
//             }
//         }, {
//             id: 'thumbnail',
//             key: function(req, file, cb) {
//                 cb(null, Date.now().toString() + 'thumbnail' + ".jpg")
//             },
//             transform: function(req, file, cb) {
//                 cb(null, sharp().resize(50, 50))
//             }
//         }]
//     })
// })

// let cpUpload = upload.fields([{ name: 'profile', maxCount: 1 }, { name: 'pan', maxCount: 1 }, { name: 'gst', maxCount: 1 }, ]);

/* Admin Login */
router.post('/adminLogin', (req, res) => {
    adminService.login(req.body, (data) => {
        res.send(data);
    });
});

/* Update Vendor */
router.post('/updateVendor', authHandler.verifyToken, (req, res) => {
    adminService.updateVendor(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Add Vendor Category */
router.post('/addVendorCategory', authHandler.verifyToken, (req, res) => {
    adminService.addVendorCategory(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Vendor category list */
router.get('/getVendorCategory', authHandler.verifyToken, (req, res) => {
    adminService.getVendorCategory(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Edit Vendor Category */
router.post('/editVendorCategory', authHandler.verifyToken, (req, res) => {
    adminService.editVendorCategory(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Update Product */
router.post('/updateProduct', authHandler.verifyToken, (req, res) => {
    adminService.updateProduct(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Add Product Category */
router.post('/addProductCategory', authHandler.verifyToken, (req, res) => {
    adminService.addProductCategory(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Product category list */
router.get('/getProductCategory', authHandler.verifyToken,  (req, res) => {
    adminService.getProductCategory(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Edit Product Category */
router.post('/editProductCategory', authHandler.verifyToken, (req, res) => {
    adminService.editProductCategory(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Active Stores */
router.get('/getActiveStores', authHandler.verifyToken, (req, res) => {
    adminService.getActiveStores(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Export Active Stores Listing */
router.get('/exportActiveStores', authHandler.verifyToken, (req, res) => {
    adminService.exportActiveStores(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get New Stores */
router.get('/getNewStores', authHandler.verifyToken, (req, res) => {
    adminService.getNewStores(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Export New Stores Listing */
router.get('/exportNewStores', authHandler.verifyToken, (req, res) => {
    adminService.exportNewStores(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Approve New Store */
router.post('/approveStore', authHandler.verifyToken, (req, res) => {
    adminService.approveStore(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Update Request */
router.get('/getUpdateRequest', authHandler.verifyToken, (req, res) => {
    adminService.getUpdateRequest(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Export Update Request Listing */
router.get('/exportUpdateRequest', authHandler.verifyToken, (req, res) => {
    adminService.exportUpdateRequest(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Approve Update Request */
router.post('/approveUpdateRequest', authHandler.verifyToken, (req, res) => {
    adminService.approveUpdateRequest(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Store Details of Active Stores */
router.get('/getActiveStores/storeDetails', authHandler.verifyToken, (req, res) => {
    adminService.activeStoreDetails(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Documents of Active Stores */
router.get('/getActiveStores/documents', authHandler.verifyToken, (req, res) => {
    adminService.activeStoreDocuments(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Inventory of Active Stores */
router.get('/getActiveStores/inventory', authHandler.verifyToken, (req, res) => {
    adminService.activeStoreInventory(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Orders of Active Stores */
router.get('/getActiveStores/orders', authHandler.verifyToken, (req, res) => {
    adminService.activeStoreOrders(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Customers Listing */
router.get('/getCustomers', authHandler.verifyToken, (req, res) => {
    adminService.getCustomers(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Export Customer Listing */
router.get('/exportCustomerListing', authHandler.verifyToken, (req, res) => {
    adminService.exportCustomers(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Customer Personal Details */
router.get('/getCustomers/personalDetails', authHandler.verifyToken, (req, res) => {
    adminService.getCustomerDetails(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Customer Orders */
router.get('/getCustomers/orders', authHandler.verifyToken, (req, res) => {
    adminService.getCustomerOrders(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Active Orders */
router.get('/getActiveOrders', authHandler.verifyToken, (req, res) => {
    adminService.getActiveOrders(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Export Active Orders to Excel */
router.get('/exportActiveOrders', authHandler.verifyToken, (req, res) => {
    adminService.exportActiveOrders(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Delivered Orders List */
router.get('/getDeliveredOrders', authHandler.verifyToken, (req, res) => {
    adminService.getDeliveredOrders(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Export Delivered Orders to Excel */
router.get('/exportDeliveredOrders', authHandler.verifyToken, (req, res) => {
    adminService.exportDeliveredOrders(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Cancelled Orders List */
router.get('/getCancelledOrders', authHandler.verifyToken, (req, res) => {
    adminService.getCancelledOrders(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Export Cancelled Orders to Excel */
router.get('/exportCancelledOrders', authHandler.verifyToken, (req, res) => {
    adminService.exportCancelledOrders(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Details of Active Orders */
router.get('/getActiveOrders/details', authHandler.verifyToken, (req, res) => {
    adminService.activeOrderDetails(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Add Promotion Banner */
router.post('/addBanner', authHandler.verifyToken, (req, res) => {
    adminService.addBanner(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Promotions List */
router.get('/getPromotions', authHandler.verifyToken, (req, res) => {
    adminService.getPromotions(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Delete Promotion Banner */
router.get('/deleteBanner', authHandler.verifyToken, (req, res) => {
    adminService.deleteBanner(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Edit Promotion Banner */
router.post('/editBanner', authHandler.verifyToken, (req, res) => {
    adminService.editBanner(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Add Delivery Boy */
router.post('/addDeliveryBoy', authHandler.verifyToken, (req, res) => {
    adminService.addDeliveryBoy(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Get Delivery Boys List */
router.get('/getDrivers', authHandler.verifyToken, (req, res) => {
    adminService.getDrivers(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Export Active Drivers Listing */
router.get('/exportActiveDrivers', authHandler.verifyToken, (req, res) => {
    adminService.exportActiveDrivers(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Export New Drivers Listing */
router.get('/exportNewDrivers', authHandler.verifyToken, (req, res) => {
    adminService.exportNewDrivers(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Approve New Driver */
router.post('/approveNewDriver', authHandler.verifyToken, (req, res) => {
    adminService.approveNewDriver(req.body, req.headers, (data) => {
        res.send(data);
    });
});

/* Search */
/*router.post('/search', authHandler.verifyToken, (req, res) => {
    adminService.search(req.body, req.headers, (data) => {
        res.send(data);
    });
});*/

module.exports = router;